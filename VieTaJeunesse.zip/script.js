

alert("Bienvenue sur Vie Ta Jeunesse. Merci de considérer à faire un don pour les enfants qui en ont besoin. / Welcome to Live Your Youth. Please consider donating for the children in need.");
