
from flask import Flask, render_template
app = Flask(__name__)

@app.route('/englishver')
def index():
    return render_template("englishver.html", )



if __name__ == '__main__':
    app.run()


